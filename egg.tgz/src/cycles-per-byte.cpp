// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cycles per byte"); }
int main(){
  announce();
  return lionss_run_workload("cycles-per-byte");
}
