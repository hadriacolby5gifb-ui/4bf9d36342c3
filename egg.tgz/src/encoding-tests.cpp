// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("encoding tests\n", stdout);
  return lionss_run_workload("encoding-tests");
}
