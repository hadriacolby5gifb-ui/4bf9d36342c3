// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("api tests"); }
int main(){
  announce();
  return lionss_run_workload("api-tests");
}
