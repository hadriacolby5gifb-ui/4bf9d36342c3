// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cold start bench\n", stdout);
  return lionss_run_workload("cold-start-bench");
}
