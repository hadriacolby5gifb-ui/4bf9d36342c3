// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("determinism tests\n", stdout);
  return lionss_run_workload("determinism-tests");
}
