# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(valgrind-massif src/valgrind-massif.cpp)
set_property(TARGET valgrind-massif PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-massif lionss pthread)

add_executable(android-arm64 src/android-arm64.cpp)
set_property(TARGET android-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-arm64 lionss pthread)

add_executable(linux-loongarch64 src/linux-loongarch64.cpp)
set_property(TARGET linux-loongarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-loongarch64 lionss pthread)

add_executable(cold-start-bench src/cold-start-bench.cpp)
set_property(TARGET cold-start-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cold-start-bench lionss pthread)

add_executable(build-pic src/build-pic.cpp)
set_property(TARGET build-pic PROPERTY CXX_STANDARD 11)
target_link_libraries(build-pic lionss pthread)

add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(encoding-tests src/encoding-tests.cpp)
set_property(TARGET encoding-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(encoding-tests lionss pthread)

add_executable(freebsd-build src/freebsd-build.cpp)
set_property(TARGET freebsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(freebsd-build lionss pthread)

add_executable(deprecations-check src/deprecations-check.cpp)
set_property(TARGET deprecations-check PROPERTY CXX_STANDARD 11)
target_link_libraries(deprecations-check lionss pthread)

add_executable(macrobench src/macrobench.cpp)
set_property(TARGET macrobench PROPERTY CXX_STANDARD 11)
target_link_libraries(macrobench lionss pthread)

add_executable(unit-tests src/unit-tests.cpp)
set_property(TARGET unit-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(unit-tests lionss pthread)

add_executable(gui-tests src/gui-tests.cpp)
set_property(TARGET gui-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(gui-tests lionss pthread)

add_executable(build-shared src/build-shared.cpp)
set_property(TARGET build-shared PROPERTY CXX_STANDARD 11)
target_link_libraries(build-shared lionss pthread)

add_executable(jumbo-build src/jumbo-build.cpp)
set_property(TARGET jumbo-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jumbo-build lionss pthread)

add_executable(license-audit src/license-audit.cpp)
set_property(TARGET license-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(license-audit lionss pthread)

add_executable(smoke src/smoke.cpp)
set_property(TARGET smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke lionss pthread)

add_executable(honggfuzz src/honggfuzz.cpp)
set_property(TARGET honggfuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(honggfuzz lionss pthread)

add_executable(hardened-runtime src/hardened-runtime.cpp)
set_property(TARGET hardened-runtime PROPERTY CXX_STANDARD 11)
target_link_libraries(hardened-runtime lionss pthread)

add_executable(function-coverage src/function-coverage.cpp)
set_property(TARGET function-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(function-coverage lionss pthread)

add_executable(dependency-pin src/dependency-pin.cpp)
set_property(TARGET dependency-pin PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-pin lionss pthread)

add_executable(api-tests src/api-tests.cpp)
set_property(TARGET api-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(api-tests lionss pthread)

add_executable(numa-bench src/numa-bench.cpp)
set_property(TARGET numa-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(numa-bench lionss pthread)

add_executable(single-header-check src/single-header-check.cpp)
set_property(TARGET single-header-check PROPERTY CXX_STANDARD 11)
target_link_libraries(single-header-check lionss pthread)

add_executable(cpplint src/cpplint.cpp)
set_property(TARGET cpplint PROPERTY CXX_STANDARD 11)
target_link_libraries(cpplint lionss pthread)

add_executable(musl-build src/musl-build.cpp)
set_property(TARGET musl-build PROPERTY CXX_STANDARD 11)
target_link_libraries(musl-build lionss pthread)

add_executable(branch-prediction src/branch-prediction.cpp)
set_property(TARGET branch-prediction PROPERTY CXX_STANDARD 11)
target_link_libraries(branch-prediction lionss pthread)

add_executable(cycles-per-byte src/cycles-per-byte.cpp)
set_property(TARGET cycles-per-byte PROPERTY CXX_STANDARD 11)
target_link_libraries(cycles-per-byte lionss pthread)

add_executable(determinism-tests src/determinism-tests.cpp)
set_property(TARGET determinism-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(determinism-tests lionss pthread)

add_executable(symbol-visibility src/symbol-visibility.cpp)
set_property(TARGET symbol-visibility PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-visibility lionss pthread)

add_executable(duplication-check src/duplication-check.cpp)
set_property(TARGET duplication-check PROPERTY CXX_STANDARD 11)
target_link_libraries(duplication-check lionss pthread)

